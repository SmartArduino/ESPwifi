if the motor chip is HR8833, please choose the 8833 code; 
if the motor chip is TB6612, PLEASE choose the TB6612.
Note, we change the power switch, since the previous is easy bad.